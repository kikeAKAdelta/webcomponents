
class ListaCompletado extends HTMLElement{



		constructor(){
			//siempre llamar al constructor super
			super();

		}

		//Cuando se conecta por primera vez al DOM
		connectedCallback(){
			//creando un shadow root
			let shadow=this.attachShadow({mode: 'open','composed':true,'bubbles':true});

			

			//creando boton
			let boton=document.createElement("input");
			boton.setAttribute('type', 'button');
			boton.setAttribute('value', 'Busqueda');
			boton.style.width='100px';


			//Creando evento
			//let evento=new new CustomEvent('key_complete', {'detail':inputText});
			let evento=new CustomEvent("list_complete");
			boton.addEventListener("list_complete", teclear(), false);
			boton.dispatchEvent(evento);
			//el escucha del evento
			//inputText.addEventListener('key_complete', )
			//inputText.addEventListener('click', key_complete, false);
			

			//Agregando al dom
			shadow.appendChild(boton);

		}

}

	function teclear () {
     		console.log('hola');
     		//let marca=new MarcaController();
     		//marca.busqueda();
	}
     

	//Definiendo un nuevo elemento
	customElements.define('list-complete',ListaCompletado);
	
// export default ListaCompletado;